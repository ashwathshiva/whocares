import HumanReview from "./HumanReview";

export default function App() {
  return <HumanReview />;
}
